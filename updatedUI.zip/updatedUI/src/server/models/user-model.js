const Users = [
    {
        name: 'mike',
        age: 31,
        id: 1,
        location: 'Dallas'
    },
    {
        name: 'sean',
        age: 32,
        id: 2,
        location: 'Dallas'
    },
    {
        name: 'jim',
        age: 38,
        id: 3,
        location: 'NY'
    },
    {
        name: 'kim',
        age: 32,
        id: 4,
        location: 'NY'
    }
];

module.exports = {Users};