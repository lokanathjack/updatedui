const {Users} = require('../models/user-model');
const jwt = require('jsonwebtoken')

const findUserByNmae = (user) => {
    return new Promise((resolve, reject) => {
        if (user) {
            const foundUser = Users.find((value) => {
                return value.name === user
            });
            if (foundUser) {
                resolve(foundUser);
            } else {
                reject(`No user found by the name of ${user}`)
            }
        }else {
            reject('Please Provide a user to look for')
        }
    })
};

const findUsersByLocation = (location) => {
    return new Promise((resolve, reject) => {
        if (location) {
            const users = Users.filter((value) => {
                return value.location === location
            });

            if (users.length <= 0) {
                reject(`No users found with location: ${location}`);
                resolve(users)
            } else {
                resolve(users)
            }
        }else {
            reject('Please provide a location')
        }
    });
}

const getUserByName = (request,reply) => {
    console.log('getUserByName function from user-controller')
    const user = request.params.name || 'mike';
    // console.log(request.auth)

    findUserByNmae(user).then((userdetail) => {
        reply.send(userdetail)
    }).catch((error) => {
        reply.send({error: error})
    })

};

const getUsersByLocation = (request, reply) => {
    let location = request.query.location;
    findUsersByLocation(location).then((userDetail) => {
        reply.send(userDetail)
    }).catch((error) => {
        reply.send({error: error})
    })
}

module.exports = {getUserByName, getUsersByLocation}