var express = require('express');
var router = express.Router();
const path = require('path')

//const {enforce} = require('@com.att.ajsc/enforce'); 
const {enforce} = require('@com.att.ajsc/enfocerjs/enFocer/enFocer.js');
const {aafRunner} = require('@com.att.ajsc/aaf');



// GET method route
  router.get( '/', function( req, res ) {
    res.sendFile( path.join( __dirname, '../views', 'login.html' ));
  });


/* POST method listing. */
router.post('/', aafRunner);


module.exports = router;
