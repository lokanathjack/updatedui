const express = require('express');
const router = express.Router();
const {getUserByName} = require('../controllers/user-controller');
const {checkAuthorization} = require('@com.att.ajsc/enfocerjs');

/* GET users listing. */
router.get('/:name',checkAuthorization,getUserByName);

module.exports = router;
