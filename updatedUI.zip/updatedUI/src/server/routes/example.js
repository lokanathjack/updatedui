/**
 * Created by rx226f on 10/10/2017.
 */
var express = require('express');
var router = express.Router();
var dashboardLogger = require('@com.att.ajsc/dashboard-logging');
var promClient = require('prom-client');
const commonNames= require('@com.att.ajsc/dashboard-logging').getComanNames();
const logger= require('@com.att.ajsc/1t-logging').logger;
const appRoot = require('app-root-path');
//const configuration = require(appRoot.path+'/config/override-configs.json');
//------------
const path = require('path');
const fs = require('fs');
const rimraf = require('rimraf');
var configuration;
const dirExist = fs.existsSync(path.resolve(process.cwd(),'config-map'));
const configDirExist = fs.existsSync(path.resolve(process.cwd(),'config'));

if (dirExist) {
    if (configDirExist) {
        rimraf(path.resolve(process.cwd(),'config'),function (err) {
            if (err) {
                logger.info('config folder is not found, it may removed already');
            }else {
                logger.info('config folder removed');
            }
        });
    }
    configuration = require(path.resolve(process.cwd(),'./config-map/override-configs.json'));
}else {
    (function (dir) {
        try {
            fs.statSync(dir);
            logger.info('config-map dir is not exist, config dir exists');
            logger.info('getting configurations from config folder...');
            configuration = require(path.resolve(process.cwd(),'./config/override-configs.json'));
        } catch (e) {
            logger.info('could not get config from config folder');
        }
    })('config');
}
//---------
const exampleRouteCount = new promClient.Counter({
    name: 'example_route_served_count',
    help: 'used to count requests served by example route',
    labelNames: ['method','code'],
    type:['type']
});


router.get('/', function(req, res, next) {
        var dataObj =  {
            "testData":"testing123"
        }
        req.ilibBusinessData = dataObj;

        exampleRouteCount.inc();
        downstreamCall(req)
            .then((value) => {
            res.send(value);
    })
    .catch((reason) => {
            res.send(reason);
    });


    //onResponseMiddleware(req, res, next);
});

var downstreamCall = function (request) {
    return new Promise(function(resolve, reject) {
        var downstreamCallInfoObj = dashboardLogger.getNewDownstreamCallObj();
        downstreamCallInfoObj.invokeEndPointName = "";
        downstreamCallInfoObj.invokeEndPointMethod = "downstreamCall";
        downstreamCallInfoObj.startTime = new Date().getTime();
        try {
            // async call
            setTimeout(function(){

                    /*
                     downstream call handler business logic here
                     */

                    downstreamCallInfoObj.endTime = new Date().getTime();
                    downstreamCallInfoObj.elapsedTime = downstreamCallInfoObj.endTime - downstreamCallInfoObj.startTime;
                    downstreamCallInfoObj.runStatus = 'C';
                    if(configuration.logging) {
                        request.headers[commonNames.property.DOWNSTREAM_CALLS_INFO].push(downstreamCallInfoObj);
                    }

                    if(request.headers[commonNames.property.DOWNSTREAM_CALLS_INFO] && request.headers[commonNames.property.DOWNSTREAM_CALLS_INFO].length > 0) {
                        logger.info("Downstream call info successfully recorded", ["example route response"]);
                        resolve({"message":"Downstream call info successfully recorded"});
                    } else {
                        reject({"message":"Downstream call info not recorded"});
                    }
                },
                0);
        }
        catch(error) {
            reject(error);
        }

    })
};

module.exports = router;