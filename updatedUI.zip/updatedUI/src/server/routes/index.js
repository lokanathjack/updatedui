var express = require('express');
var router = express.Router();
const path = require('path')
const {aafRunner} = require('@com.att.ajsc/aaf')
const {enforce} = require('@com.att.ajsc/enfocerjs');
const {callLimiter} = require('@com.att.ajsc/requestlimiterjs');
const appRoot = require('app-root-path');
console.log('appRoot:' + appRoot);
console.log('path:' + path);

/* GET home page. */
router.get('/',enforce, function (req, res, next) {
    console.log("Test New DirName" + __dirname);
    res.sendFile( path.join( __dirname, '../public/js/angular', 'index.html' ));
   
});

module.exports = router;
