/**
 * Created by rx226f on 10/10/2017.
 */
var express = require('express');
var router = express.Router();
var promClient = require('prom-client');

//example metric types user can use this type of metrics any where in code.
const histogram = new promClient.Histogram({
    name: 'histogram_name',
    help: 'what this histogram is helping for?(user need to add appropriate description here)',
    labelNames: ['code'],
    type:['type']
});

const counter = new promClient.Counter({
    name: 'counter_name',
    help: 'what this counter is helping for?(user need to add appropriate description here)',
    labelNames: ['method','code'],
    type:['type']
});

const gauge =  new promClient.Gauge({
    name: 'gauge_name',
    help: 'what this gauge is helping for?(user need to add appropriate description here)',
    labelNames: ['method', 'code'],
    type:['type']
});



/* GET home page. */
router.get('/', function(req, res, next) {
    promClient.collectDefaultMetrics();
    res.send(promClient.register.metrics());
});

module.exports = router;