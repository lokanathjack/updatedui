var express = require('express');
var router = express.Router();
const logger= require('@com.att.ajsc/1t-logging').logger;
const appRoot = require('app-root-path');
const logConstraints = require('@com.att.ajsc/1t-logging').logConstraints;
const tssErrorCodes = require('../../../error-codes/tss-error-codes.js');
const tssErrorTmplGenerator = require('../../../helperfunctions/tssErrorTmplGenerator.js');
const serverSideValidation = require('../../../helperfunctions/serverSideValidation.js');
var lastReqTimes = [];

router.post('/serviceError', function(req, res, next) {
    //making service error,  this service expect userName, Password and email,  if any thing is missing it will send tss error.
    if(req.body.username && req.body.password && serverSideValidation.email(req.body.email)) {
        res.send(req.body);
    } else {
        let errorObj = new tssErrorCodes.InvalidInput("missing or invalid emailId", [req.body.username, req.body.password, req.body.email], req.body.path);
        logger.error(tssErrorTmplGenerator.generateTSSErrorTmpl(errorObj), [logConstraints.TAGS.TSS_SERVICE_ERROR]);
        res.send(tssErrorTmplGenerator.generateTSSErrorTmpl(errorObj));
    }
});

router.post('/policyError', function(req, res, next) {
    //making policy error,  this service expect 5calls in a min,  if it exceeds 5 calls it will send ExceedsReqPerMin error.
    var lastFiveCallsDuration = 60001;
    lastReqTimes.push(new Date().getTime());
    if(lastReqTimes.length > 5) {
        lastReqTimes.shift();
        lastFiveCallsDuration = lastReqTimes[4] - lastReqTimes[0];
    }
    if(lastFiveCallsDuration < 60000){
        let errorObj = new tssErrorCodes.ExceedsReqPerMin("exceeds requests per minute count", [req.body.username, req.body.password, req.body.email], req.url.path);
        logger.error(tssErrorTmplGenerator.generateTSSErrorTmpl(errorObj), [logConstraints.TAGS.TSS_POLICY_ERROR]);
        res.send(tssErrorTmplGenerator.generateTSSErrorTmpl(errorObj));
    } else {
        res.send(req.body);
    }
});

module.exports = router;