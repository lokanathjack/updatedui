import { Component, OnInit } from '@angular/core';
import {Router,RouterModule, NavigationExtras, Routes} from "@angular/router";
import { FormGroup, FormControl } from '@angular/forms';
import { ModuleWithProviders } from "@angular/core";
import { SidDescMenu } from '../model/commonSidData.model';
import { Http } from '@angular/http';
import { environment } from 'environments/environment';
import { CookieService } from 'ngx-cookie-service';

@Component({
  selector: 'app-ubmmainui',
  templateUrl: './ubmmainui.component.html',
  styleUrls: ['./ubmmainui.component.css']
})
export class UbmmainuiComponent implements OnInit {
  cookieValue : string[] = [];
  public constructor(private http:Http,private router: Router,private sidDescMenu: SidDescMenu,private cookieService: CookieService) { }
  //const routes: Routes = [];
//apiURL : string;
apiRoot= environment.apiUrl;
  //apiRoot: string = 'http://zltv6463.vci.att.com:30102/restservices/helloworld/v1/service/getSIDID';
  valueStr: string;
  valueStrSID: string;
  version:string
  versionDate:string;
  activity:string;
  originalJson: string;
  cookieServiceGet: string[] = [];
 commSidType='';
 commRequestType='';
 commSidRestriction='';
  formdata;
  ngOnInit() {
    let taskelement:HTMLElement=document.getElementById('application') as HTMLElement;
    taskelement.className = 'nav-link title-head active ml20';
this.cookieValue = this.cookieService.get('attESHr').split("|",3);
    
    var firstname = this.cookieValue[0]
    var lastname = this.cookieValue[1]
    var attuid = this.cookieValue[2].split("@")[0];
    //console.log("userid loogeed == "+this.cookieValue+"firstname "+firstname+"lastname "+lastname+" attuid "+attuid);
    this.sidDescMenu.firstName = firstname;
    this.sidDescMenu.lastName = lastname;
    this.sidDescMenu.attuid = attuid;
    console.log("userid loogeed == "+this.cookieValue+"firstname "+this.sidDescMenu._firstName+"lastname "+this.sidDescMenu._lastName+" attuid "+this.sidDescMenu._attuid);
    this.formdata = new FormGroup({
      commSidType: new FormControl('Quick Update'),
      commRequestType: new FormControl('Standard'),
      commSidRestriction: new FormControl('None')
      });
      this.search('Moo');
  }

  search(term: string) {
    let promise = new Promise((resolve, reject) => {
      this.http.get(this.apiRoot+'/restservices/helloworld/v1/service/getSIDID')
        .toPromise()
        .then(
          res => { // Success
            this.sidDescMenu.originalJson=res.json();
            console.log(this.sidDescMenu.originalJson);
           // this.valueStr =JSON.parse(res.json());            
            this.valueStrSID=res.json()["sidId"];
            this.version=res.json()["version"];
            this.versionDate=res.json()["versionDate"];
            this.activity=res.json()["activity"];
            console.log(this.valueStrSID);
            this.sidDescMenu.setSidId(this.valueStrSID);
            this.sidDescMenu.setVersion(this.version);
            this.sidDescMenu.setVersionDate(this.versionDate);
            this.sidDescMenu.setActivity(this.activity);
            console.log(this.sidDescMenu.getSidId());
          },
          msg => { // Error
            reject(msg);
          }
        );
    });
    return promise;
  }
  
  public onSubmit(data) {
    this.sidDescMenu.setSidType(data.commSidType);
    this.sidDescMenu.setRequestType(data.commRequestType);
    this.sidDescMenu.setSidRestriction(data.commSidRestriction);    
  this.router.navigate(["narrative"]);
  }

}
