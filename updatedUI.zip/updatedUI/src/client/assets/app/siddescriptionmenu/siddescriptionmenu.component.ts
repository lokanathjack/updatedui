import { Component, OnInit, Injectable, Input } from '@angular/core';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { Http, Response } from '@angular/http';
import { HttpClient } from '@angular/common/http'
import { Observable } from "rxjs";
import { map } from "rxjs/operators";
import {ActivatedRoute, Router} from "@angular/router";
import { SidDescMenu } from '../model/commonSidData.model';
import { SidNarrativeData } from '../model/sidNarrativeData.model';
import { environment } from 'environments/environment';

@Component({
  selector: 'app-siddescriptionmenu',
  templateUrl: './siddescriptionmenu.component.html',
  styleUrls: ['./siddescriptionmenu.component.css']
})
export class SiddescriptionmenuComponent implements OnInit {
  public requesttype: string;
  public sidID : string;
  apiRoot= environment.apiUrl;
  @Input() sidtype: string;
  version:String;
  versionDate:Date;
  activity :string;
  sidComponentForm: FormGroup;
  submitted = false;
  blnSIDEmpty: boolean = false;
  
  constructor(private http:Http,private httpClient:HttpClient, private router: Router,private route: ActivatedRoute,public sidDescMenu: SidDescMenu,private formBuilder: FormBuilder) { 
  // this.sidtype=sidDescMenu.getSidType();
  // this.requesttype=sidDescMenu.getRequestType();
  // this.sidID=sidDescMenu.getSidId();
  }

  ngOnInit() {
    this.route.queryParams.subscribe(params => {
      let sidID = params["sidId"];
      let taskName = params["taskName"];
      console.log("ON LOAD ngInit SID ID="+sidID+"::taskName="+taskName);
      if(sidID !='undefined' && sidID !=''){
      this.getNarrativeDatabySIDId(sidID,taskName);
      }
    });
    this.sidtype=this.sidDescMenu.getSidType();
    this.requesttype=this.sidDescMenu.getRequestType();
    this.sidID=this.sidDescMenu.getSidId();
    this.version=this.sidDescMenu.getVersion();
    this.versionDate=this.sidDescMenu.getVersionDate();
    this.activity=this.sidDescMenu.getActivity();
    this.sidComponentForm = this.formBuilder.group({
      sIDDescription: ['',Validators.required]
  });
  }

  get f() {
    return this.sidComponentForm.controls;
  }

  validateChildForm(): Boolean {
    let sidbutton:HTMLElement=document.getElementById('sidbutton') as HTMLElement;
    sidbutton.click();
    let sidDesc= this.sidComponentForm.get('sIDDescription').value;
        console.log('sidDesc'+sidDesc);
        this.sidDescMenu.sidDescription=sidDesc;

        if (sidDesc == "") {
           return this.blnSIDEmpty = false;
        }else{
           return this.blnSIDEmpty = true;
        }
    ;
}

sidDiscrForm(sidComponentForm){
  this.submitted=true;
  if(!sidComponentForm.valid ) {
      console.log("INValid:::::sidform");
         return;
     } else {
        // success code comes here.
        console.log("sidform::::::::::::success");
     }   


public  getNarrativeDatabySIDId(sidId,activity) {
  console.log("getNarrativeDataby::SIDId="+sidId+":::Task Name="+activity);
  var url = this.apiRoot+'/restservices/helloworld/v1/service/getNarrativeDetails?sidId='+sidId;
    this.httpClient.get(url).subscribe( data => {
      if(data!=null){
     let nrtveData=JSON.parse(JSON.stringify(data));
     this.sidID=nrtveData['sidId'];
     this.sidtype=nrtveData['sidType'];
     this.requesttype=nrtveData['sidReqType'];
     this.version=nrtveData['version'];
     this.versionDate=nrtveData['versionDate'];
     this.activity=nrtveData['activity'];
     this.sidComponentForm = this.formBuilder.group({
       sIDDescription: [nrtveData['sidDescription'],Validators.required]
       });
      }
      return data;
    });
}

}
