import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ubmapplication',
  templateUrl: './ubmapplication.component.html',
  styleUrls: ['./ubmapplication.component.css']
})
export class UbmapplicationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    let pageName:HTMLElement=document.getElementById('pageName') as HTMLElement;
    pageName.textContent="Application";
  }

}
