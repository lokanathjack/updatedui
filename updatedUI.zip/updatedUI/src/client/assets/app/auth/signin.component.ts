import { Component } from "@angular/core";
import { FormGroup, FormControl, Validators } from "@angular/forms";
import {AuthService} from "../messages/http.service";
import { NgForm } from "@angular/forms";
@Component({
    selector: 'app-signin',
    templateUrl: './signin.component.html'
})
export class SigninComponent {
    myForm: FormGroup;
    authenticated = false;
    authorized = false;
    unAuthorized = false;
    token = '';

    constructor(private authService: AuthService) {}

    onSubmit(form: NgForm) {
        this.authService.callAuthService(form.value)
            .subscribe(
                (response:any) => {
                    const data = response;
                    console.log(data);

                    if (data.Message || data.message) {
                        this.authenticated = true;
                        this.unAuthorized = false;
                        this.token = data.token;

                    }
                },
                (error) => {
                    if (error) {
                        console.log(error)
                        this.unAuthorized = true
                    }
                }
            )
    }

    getUserInfo() {
        this.authService.getUser(this.token)
            .subscribe(
                (result:any) => {
                    console.log(result)
                },
                error2 => console.log('error: ', error2.error.Message)
            )
    }
}