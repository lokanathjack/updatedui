import { Routes, RouterModule } from "@angular/router";
import { HttpClientModule, HttpClientJsonpModule } from '@angular/common/http';
import {HttpModule} from "@angular/http";

import { MessagesComponent } from "./messages/messages.component";
import { AuthenticationComponent } from "./auth/authentication.component";
import { AUTH_ROUTES } from "./auth/auth.routes";
import { UbmapplicationComponent } from './ubmapplication/ubmapplication.component';
import { UbmmainuiComponent } from './ubmmainui/ubmmainui.component';
import { SiddescriptionmenuComponent } from './siddescriptionmenu/siddescriptionmenu.component';
import { NarrativeComponent } from './narrative/narrative.component';
import { ApprovalComponent } from './approval/approval.component';
import { MytaskComponent } from './mytask/mytask.component';


const APP_ROUTES: Routes = [
      { path: '', redirectTo: '/ubmapplication', pathMatch: 'full' },
     { path: 'index', redirectTo: '/ubmapplication', pathMatch: 'full' },
    { path: 'messages', component: MessagesComponent },
    { path: 'auth', component: AuthenticationComponent, children: AUTH_ROUTES },
       { path: 'ubmapplication',component: UbmapplicationComponent},
        { path: 'ubmmainui',component: UbmmainuiComponent},
            { path: 'narrative',component: NarrativeComponent},
 { path: 'siddescriptionmenu',component: SiddescriptionmenuComponent},
      { path: 'approval',component: ApprovalComponent},
       { path: 'mytasks',component: MytaskComponent}

];

export const routing = RouterModule.forRoot(APP_ROUTES);