export class User {
    title: string;
    phone: string;
    emailId: string;
    'firstName': string;
    'attuid': string;
    'lastName': string;
    requestorPhone: string;
    requestorEmailId: string;
    constructor(){};
}