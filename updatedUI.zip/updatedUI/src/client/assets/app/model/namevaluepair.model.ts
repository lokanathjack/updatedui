export class Namevaluepair {
    public name: string;
    public value: string;
}
