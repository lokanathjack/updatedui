export class BDContact {
    bdPhone: string;
    bdEmailId: string;
    constructor(){};
}