import { Component, OnInit, ViewChild } from '@angular/core';
import { SiddescriptionmenuComponent } from '../siddescriptionmenu/siddescriptionmenu.component';
import { Router } from '@angular/router';

@Component({
  selector: 'app-approval',
  templateUrl: './approval.component.html',
  styleUrls: ['./approval.component.css']
})
export class ApprovalComponent implements OnInit {
  @ViewChild(SiddescriptionmenuComponent) child;
  constructor(private router: Router) { }

  ngOnInit() {
    
    //this.child.sidtype;
    //console.log(this.child.sidtype);
  }

}
