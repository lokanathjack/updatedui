import { Component, OnInit, Injectable, Input, ViewChild } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { Http, Response, RequestOptions,URLSearchParams} from '@angular/http';
import { HttpClient, HttpHeaders  } from '@angular/common/http'
import { Headers } from '@angular/http';
import { Observable } from "rxjs";
import { map } from "rxjs/operators";
import {ActivatedRoute} from "@angular/router";
import { SidDescMenu } from '../model/commonSidData.model';
import { Namevaluepair } from '../model/namevaluepair.model';
import { User } from '../model/user.model';
import { multipledropdown } from '../model/multipledropdown.model';
import { CommonserviceService } from "../commonservice.service";
//import { environment } from '../../environments/environment';
import { environment } from 'environments/environment';
import { SidNarrativeData } from '../model/sidNarrativeData.model';
import { SiddescriptionmenuComponent } from '../siddescriptionmenu/siddescriptionmenu.component';
import { SelectorMatcher } from '@angular/compiler';



@Component({
  selector: 'app-narrative',
  templateUrl: './narrative.component.html',
  styleUrls: ['./narrative.component.css']
})

export class NarrativeComponent implements OnInit {
  narrative: FormGroup;
  narrativeForm:FormGroup;
  apiRoot= environment.apiUrl;
  keys: String[];
  valueStr: string;
  valueStrWebPhone = [];
  valueStrWebPhoneF = [];
  valueStrGroup: User[];
  valueFinanceApprover =[];
  bdContactList:multipledropdown[] = [];
  mouseOver =[];
  valueRequiredCoreAppover =[];
  valueRequiredCoreAppoverList: string[]=[];
  valueProductAppover = [];
  productApproverList:multipledropdown[] = [];
  valueproductApproverList: string[]=[];
  valueChannelAppover = [];
  valueAlternateAppover =[];
  reqdropdownList: multipledropdown[] = [];
  selectedItems = [];
  singledropdownSettings = {};
  multidropdownSettings={};
  reasonCodeList:multipledropdown[] = [];
  valuMarkets =[];
  reasonCode =[];
  marketContactList:multipledropdown[] = [];
  submitted = false;
  saved = false;
  sidNarrativeData :  SidNarrativeData =new SidNarrativeData;
  public requesttype: string;
  public sidID : string;
  public sidRestriction : string;
  loggedRequestor : string;
  error=false;
  //saveError=false;
  modelFlag:Boolean;
  requesterselectItems = [];
  bdContactSelectItems=[];
  selectedmarketContactList=[];
  dataNarReasonCode=[];
  dataNarOptionalPrdAppr=[]
  
  
  constructor(private http:Http,private httpClient:HttpClient, private route: ActivatedRoute,private sidDescMenu: SidDescMenu,private sidp8: CommonserviceService,private formBuilder: FormBuilder) { 
    
  }
  
  @ViewChild(SiddescriptionmenuComponent) private siddescriptionmenuComponent: SiddescriptionmenuComponent;

  ngOnInit() {
    let taskelement:HTMLElement=document.getElementById('application') as HTMLElement;
    taskelement.className = 'nav-link title-head active ml20';
    

    this.narrativeForm = new FormGroup({
          requestorName:new FormControl('') ,
          requestortitle: new FormControl(''),
          requestorphone: new FormControl(''),
          requestoremailId: new FormControl(''),
          bdContactName: new FormControl(''),
          bdContacttitle: new FormControl(''),
          bdContactphone: new FormControl(''),
          bdContactemailId: new FormControl(''),
          requestedDate: new FormControl(''),
          sidRestriction: new FormControl(''),
          telegenceImpacted: new FormControl(''),
          itProposedDate: new FormControl(''),
          titanEnablerProposedImplementationDate: new FormControl(''),
          narrativeProvidedBy:new FormControl(''),
          narrativeTimeAndDateProvided:new FormControl(''),
          marketContactList:new FormControl(''),
          narrative:new FormControl(''),
          titanEnabledImpacted:new FormControl(''),
          productApprovers:new FormControl(''),
          requiredCoreApproval : new FormControl(''),
          friendlyName:new FormControl(''),
          marketNarOverallReq: new FormControl(''),
          impactWifi:new FormControl(''),
          marketNarComments:new FormControl(''),
          reasonCode:new FormControl('')
    });



    this.narrativeForm = this.formBuilder.group({
      requestorName: ['', Validators.required],
      requestedDate: ['', Validators.required],
      bdContactName:['', Validators.required],
      marketNarOverallReq:['',Validators.required],
      friendlyName:[''],
      productApprovers:['',Validators.required],
      impactWifi:[],
      telegenceImpacted:[{value: '', disabled: true}],
      requiredCoreApproval:[],
      titanEnabledImpacted:[{value: '', disabled: true}],
      sidRestriction:[],
      marketContactList:[],
      itProposedDate:[{value: '', disabled: true}],
      titanEnablerProposedImplementationDate:[{value: '', disabled: true}],
      dataNarrRDDate:[{value: '', disabled: true}],
      marketNarComments:[],
      reasonCode:[]

  });
    
    // this.loggedRequestor = this.sidDescMenu._firstName+","+this.sidDescMenu._lastName+":"+this.sidDescMenu._attuid;
    console.log("page load from cookies=NARRATIVE CMPT =attuid=="+this.sidDescMenu._attuid);
    if(this.sidDescMenu._attuid!='undefined' && this.sidDescMenu._attuid!=''){
    this.requesterselectItems = [
      { item_id: this.sidDescMenu._attuid, item_text: this.sidDescMenu._firstName+','+this.sidDescMenu._lastName+':'+this.sidDescMenu._attuid }
    ];
  }
       
      
      this.route.queryParams.subscribe(params => {
          let sidID = params["sidId"];
          let taskName = params["taskName"];
          console.log("ON LOAD ngInit SID ID="+sidID+"::taskName="+taskName);
          if(sidID !='undefined' && sidID !=''){
             this.getNarrativeDatabySIDId(sidID,taskName);// need to enable once proper data form Service
             //this.getNarrativeDatabySIDId('20181115767',taskName); //testing purpose
          }
        });
    
    this.sidID=this.sidDescMenu.getSidId();
    this.requesttype=this.sidDescMenu.getRequestType();
    this.sidRestriction=this.sidDescMenu.getSidRestriction();
    this.searchMouseOver('Moo');
    this.searchGroup('Moo');
    this.searchGroupFinance('Moo');
    this.markets(this.requesttype,this.sidID,'NARRATIVE');
    this.requiredCoreApprovers();
    this.coreApproval();
    this.webphone(this.sidDescMenu._attuid);
    this.singledropdownSettings = {
      singleSelection: true,
      idField: 'item_id',
      textField: 'item_text',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 3,
      allowSearchFilter: true
    };

    this.multidropdownSettings= {
      singleSelection: false,
      idField: 'item_id',
      textField: 'item_text',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 3,
      allowSearchFilter: true
    };
  } //on init end


  public openDocumentumWindow(p8Foldername) {
    var foldername = p8Foldername;
    var p8url='';
    this.sidp8.fileNetService(foldername).subscribe( data => {
      console.log(data)
      window.open(data);
      //p8url=data;
      });
      //console.log(p8url);
     //window.open( p8url);
  /*if(!newwin.opener)
   newwin.opener = self;
  newwin.focus();
 return false;*/
  }

  public onChangeR(item: any) {  // event will give you full breif of action
    
    this.webphone(item.item_id);
  }
  public onChangeF(item: any){  // event will give you full breif of action
    this.webphonef(item.item_id);
  } 

  get f() {
    return this.narrativeForm.controls;
    }
    
  enterForm(narrativeForm) {
    this.submitted = true;
    this.error=true;
    let flag=this.siddescriptionmenuComponent.validateChildForm();
    this.modelFlag=flag;
    console.log("NARRATIVE : SIDDISCRIPTION form Flag="+flag);
    if(flag){
    if(!narrativeForm.valid) {
      console.log("INValid::::NARRATIVE");
        return;
    }else {
       // success code comes here.
       this.error=false;
       console.log("Valid:::::NARRATIVE");
    }                
  }
}

onSaveFormValidation(narrativeForm) {
  this.saved = true;
  this.error=true;
  let flag=this.siddescriptionmenuComponent.validateChildForm();
  this.modelFlag=flag;
  console.log("NARRATIVE : SIDDISCRIPTION form Flag="+flag);
  if(flag){
  if(!narrativeForm.valid) {
    console.log("INValid::::NARRATIVE");
      return;
  }else {
     // success code comes here.
     this.error=false;
     console.log("Valid:::::NARRATIVE");
  }                
}
}
  saveForm(){
   // console.log("======Narrative STAVE START======"+this.narrativeForm.value.productApprovers[0].item_text);    
    this.sidNarrativeData.sidId = this.sidDescMenu.getSidId();
    this.sidNarrativeData.sidDescription = this.sidDescMenu.getSidDesc();
    this.sidNarrativeData.sidType = this.sidDescMenu.getSidType();
    this.sidNarrativeData.sidReqType =this.sidDescMenu.getRequestType();
    this.sidNarrativeData.version = this.sidDescMenu.getVersion();
    this.sidNarrativeData.versionDate = this.sidDescMenu.getVersionDate();
    this.sidNarrativeData.activity=this.sidDescMenu.getActivity();
    this.sidNarrativeData.narrative.requestorName=this.narrativeForm.value.requestorName[0].item_text;
    this.sidNarrativeData.narrative.bdContactName=this.narrativeForm.value.bdContactName[0].item_text;
    this.sidNarrativeData.narrative.requestedDate=this.narrativeForm.value.requestedDate;
    this.sidNarrativeData.narrative.sidRestriction=this.sidDescMenu.getSidRestriction();
    this.sidNarrativeData.narrative.telegenceImpacted=this.narrativeForm.value.telegenceImpacted;
    this.sidNarrativeData.narrative.itProposedDate=this.narrativeForm.value.itProposedDate;
    this.sidNarrativeData.narrative.titanEnablerProposedImplementationDate=this.narrativeForm.value.titanEnablerProposedImplementationDate;
    this.sidNarrativeData.narrative.narrativeProvidedBy=this.narrativeForm.value.narrativeProvidedBy;
    this.sidNarrativeData.narrative.narrativeTimeAndDateProvided=this.narrativeForm.value.narrativeTimeAndDateProvided;
    this.sidNarrativeData.narrative.markets=this.narrativeForm.value.marketContactList;    
    this.sidNarrativeData.narrative.titanEnabledImpacted=this.narrativeForm.value.titanEnabledImpacted;
    if(this.narrativeForm.value.productApprovers == ""){
    this.sidNarrativeData.narrative.productApprovers=null;}
    else{
      this.sidNarrativeData.narrative.productApprovers=this.narrativeForm.value.productApprovers;
    }
    //this.sidNarrativeData.narrative.requiredCoreApproval=this.narrativeForm.value.requiredCoreApproval;
    this.sidNarrativeData.actionTaken='save';
    //this.sidNarrativeData.userIdTakingAction=this.narrativeForm.value.requestorName[0].item_text.attuid;
    this.sidNarrativeData.comments=this.narrativeForm.value.marketNarComments;
    this.sidNarrativeData.reasonCode=this.narrativeForm.value.reasonCode;
    this.sidNarrativeData.narrative.friendlyName=this.narrativeForm.value.friendlyName;
    this.sidNarrativeData.narrative.impactWifi=this.narrativeForm.value.impactWifi;
    this.sidNarrativeData.narrative.marketNarOverallReq=this.narrativeForm.value.marketNarOverallReq;
    console.log(JSON.stringify(this.sidNarrativeData));  
    
    var jsonArr;
     var jsonStr = JSON.stringify(this.sidDescMenu.originalJson);
     var jsonMod = JSON.stringify(this.sidNarrativeData);
     //console.log("original---"+jsonStr);
      var obj  = [];
      obj.push(JSON.parse(jsonStr));
      obj.push(JSON.parse(jsonMod));
      jsonArr = JSON.stringify(obj);
     
    

      console.log(jsonArr);
      if(this.modelFlag){
    this.http.post(this.apiRoot+'/restservices/helloworld/v1/service/saveQUNarrative',jsonArr)
        .subscribe(
        (val) => {
          console.log('POST call successful value returned in body',
            val);
        },
        response => {
          console.log('POST call in error', response);
        },
        () => {
          console.log('The POST observable is now completed.');
        });
      }
  }

  submitForm(){
    // console.log("======Narrative STAVE START======"+this.narrativeForm.value.productApprovers[0].item_text);    
    this.sidNarrativeData.sidId = this.sidDescMenu.getSidId();
    this.sidNarrativeData.sidDescription = this.sidDescMenu.getSidDesc();
    this.sidNarrativeData.sidType = this.sidDescMenu.getSidType();
    this.sidNarrativeData.sidReqType =this.sidDescMenu.getRequestType();
    this.sidNarrativeData.version = this.sidDescMenu.getVersion();
    this.sidNarrativeData.versionDate = this.sidDescMenu.getVersionDate();
    this.sidNarrativeData.activity=this.sidDescMenu.getActivity();
    this.sidNarrativeData.narrative.requestorName=this.narrativeForm.value.requestorName[0].item_text;
    this.sidNarrativeData.narrative.bdContactName=this.narrativeForm.value.bdContactName[0].item_text;
    this.sidNarrativeData.narrative.requestedDate=this.narrativeForm.value.requestedDate;
    this.sidNarrativeData.narrative.sidRestriction=this.sidDescMenu.getSidRestriction();
    this.sidNarrativeData.narrative.telegenceImpacted=this.narrativeForm.value.telegenceImpacted;
    this.sidNarrativeData.narrative.itProposedDate=this.narrativeForm.value.itProposedDate;
    this.sidNarrativeData.narrative.titanEnablerProposedImplementationDate=this.narrativeForm.value.titanEnablerProposedImplementationDate;
    this.sidNarrativeData.narrative.narrativeProvidedBy=this.narrativeForm.value.narrativeProvidedBy;
    this.sidNarrativeData.narrative.narrativeTimeAndDateProvided=this.narrativeForm.value.narrativeTimeAndDateProvided;
    this.sidNarrativeData.narrative.markets=this.narrativeForm.value.marketContactList;    
    this.sidNarrativeData.narrative.titanEnabledImpacted=this.narrativeForm.value.titanEnabledImpacted;
    if(this.narrativeForm.value.productApprovers == ""){
    this.sidNarrativeData.narrative.productApprovers=null;}
    else{
      this.sidNarrativeData.narrative.productApprovers=this.narrativeForm.value.productApprovers;
    }
    //this.sidNarrativeData.narrative.requiredCoreApproval=this.narrativeForm.value.requiredCoreApproval;
    this.sidNarrativeData.actionTaken='submit';
    //this.sidNarrativeData.userIdTakingAction=this.narrativeForm.value.requestorName[0].item_text.attuid;
    this.sidNarrativeData.comments=this.narrativeForm.value.marketNarComments;
    this.sidNarrativeData.reasonCode=this.narrativeForm.value.reasonCode;
    this.sidNarrativeData.narrative.friendlyName=this.narrativeForm.value.friendlyName;
    this.sidNarrativeData.narrative.impactWifi=this.narrativeForm.value.impactWifi;
    this.sidNarrativeData.narrative.marketNarOverallReq=this.narrativeForm.value.marketNarOverallReq;
    console.log(JSON.stringify(this.sidNarrativeData));  
     
     var jsonArr;
      var jsonStr = JSON.stringify(this.sidDescMenu.originalJson);
      var jsonMod = JSON.stringify(this.sidNarrativeData);
      //console.log("original---"+jsonStr);
       var obj  = [];
       obj.push(JSON.parse(jsonStr));
       obj.push(JSON.parse(jsonMod));
       jsonArr = JSON.stringify(obj);
      
     
 
       console.log(jsonArr);
       if(this.modelFlag){
     this.http.post(this.apiRoot+'/restservices/helloworld/v1/service/saveQUNarrative',jsonArr)
         .subscribe(
         (val) => {
           console.log('POST call successful value returned in body',
             val);
         },
         response => {
           console.log('POST call in error', response);
         },
         () => {
           console.log('The POST observable is now completed.');
         });
        }
   }
  onItemSelect(item: any) {
    console.log(item);
    
  }

  onItemSelectProducts(item: any) {
    console.log("single =item for prodcucts="+item);
  }


  onSelectAll(items: any) {
    console.log(items);
  }
  onSelectAllProducts(items: any) {
    console.log("items for Products==="+items);
  }

  requiredCoreApprovers() {
    let promise = new Promise((resolve, reject) => {
      this.http.get(this.apiRoot+'/restservices/helloworld/v1/service/getAllGroupMembers?groupName=CoreApprovers')
        .toPromise()
        .then(
          res => { // Success
           //console.log(res.json());
           let multipledropdownOption ;
           this.valueRequiredCoreAppover = res.json();
           for (var i = 0; i < this.valueRequiredCoreAppover.length; i++) {
            let valueGroup = this.valueRequiredCoreAppover[i];
            
            multipledropdownOption = valueGroup.firstName + ',' + valueGroup.lastName + ':' + valueGroup.attuid;
            this.valueRequiredCoreAppoverList.push(multipledropdownOption);
            this.valueRequiredCoreAppoverList = JSON.parse(JSON.stringify(this.valueRequiredCoreAppoverList));
          }
          this.sidNarrativeData.narrative.requiredCoreApproval = this.valueRequiredCoreAppoverList;
          },
          msg => { // Error
            reject(msg);
          }
        );
    });
    return promise;
  }
  searchMouseOver(term: string) {
    let promise = new Promise((resolve, reject) => {
      this.http.get(this.apiRoot+'/restservices/helloworld/v1/service/getMouseOverText?screenName=Narrative')
        .toPromise()
        .then(
          res => { // Success
           //console.log(res.json());
           this.mouseOver = res.json();
           //console.log(this.mouseOver);
           /*this.mouseOver.forEach((value: string, key: string) => {
            console.log(key, value);
        });*/
          },
          msg => { // Error
            reject(msg);
          }
        );
    });
    return promise;
  }
  searchGroupFinance(term: string) {
    let promise = new Promise((resolve, reject) => {
      this.http.get(this.apiRoot+'/restservices/helloworld/v1/service/getAllGroupMembers?groupName=Finance%20Approver')
        .toPromise()
        .then(
          res => { // Success
           //console.log(res.json());
           this.valueFinanceApprover = res.json();
           
           for (var i = 0; i < this.valueFinanceApprover.length; i++) {
            let valueGroup = this.valueFinanceApprover[i];
            let multipledropdownOption = new multipledropdown();
            multipledropdownOption.item_id = valueGroup.attuid;
            multipledropdownOption.item_text = valueGroup.firstName + ',' + valueGroup.lastName + ':' + valueGroup.attuid;
            this.bdContactList.push(multipledropdownOption);
            //console.log("this.reqdropdownList----------" + JSON.stringify(this.reqdropdownList));
            this.bdContactList = JSON.parse(JSON.stringify(this.bdContactList));
          }

          },
          msg => { // Error
            reject(msg);
          }
        );
    });
    return promise;
  }
  searchGroup(term: string) {
    let promise = new Promise((resolve, reject) => {
      this.http.get(this.apiRoot+'/restservices/helloworld/v1/service/getAllGroupMembers?groupName=Requestor')
        .toPromise()
        .then(
          res => { // Success
            //console.log(res.json());
            this.valueStrGroup = res.json();
            for (var i = 0; i < this.valueStrGroup.length; i++) {
              let valueGroup = this.valueStrGroup[i];
              let multipledropdownOption = new multipledropdown();
              multipledropdownOption.item_id = valueGroup.attuid;
              multipledropdownOption.item_text = valueGroup.firstName + ',' + valueGroup.lastName + ':' + valueGroup.attuid;
              this.reqdropdownList.push(multipledropdownOption);
              //console.log("this.reqdropdownList----------" + JSON.stringify(this.reqdropdownList));
              this.reqdropdownList = JSON.parse(JSON.stringify(this.reqdropdownList));
            }
            //this.keyValuePairsModel = res.json().keyValuePairsModel;
            //alert(this.keyValuePairsModel.length);
            //this.groupUsers = res.json();
            //this.mapUsers(this.groupUsers);
            
            //this.valueStrGroup = res.json();
            //console.log(this.valueStrGroup.find(res => res.groupName=='Requestor' && res.keyValuePairsModel));
          },
          msg => { // Error
            reject(msg);
          }
        );
    });
    return promise;
  }
  
  webphone(term: string) {
    let promise = new Promise((resolve, reject) => {
      this.http.get(this.apiRoot+'/restservices/helloworld/v1/service/requestor?attuid='+term)
        .toPromise()
        .then(
          res => { // Success
            //console.log(res.json());
            this.valueStrWebPhone = res.json();   
            this.sidNarrativeData.userIdTakingAction=term;        
          this.sidNarrativeData.narrative.requestor.requestorPhone=this.valueStrWebPhone['requstorPhone'];
          this.sidNarrativeData.narrative.requestor.requestorEmailId=this.valueStrWebPhone['requestorEmailId']; 
          },
          msg => { // Error
            reject(msg);
          }
        );
    });
    return promise;
  }

  webphonef(term: string) {
    let promise = new Promise((resolve, reject) => {
      this.http.get(this.apiRoot+'/restservices/helloworld/v1/service/requestor?attuid='+term)
        .toPromise()
        .then(
          res => { // Success
            //console.log(res.json());
            this.valueStrWebPhoneF = res.json();
          this.sidNarrativeData.narrative.bdContact.bdPhone=this.valueStrWebPhoneF['requstorPhone'];
          this.sidNarrativeData.narrative.bdContact.bdEmailId=this.valueStrWebPhoneF['requestorEmailId']; 
          },
          msg => { // Error
            reject(msg);
          }
        );
    });
    return promise;
  }
  
  markets(sidtype: string,sidid: string,screenname: string) {
    let promise = new Promise((resolve, reject) => {
      screenname='NARRATIVE';
      this.http.get(this.apiRoot+'/restservices/helloworld/v1/service/getConfigDetails?sidType='+sidtype+'&pageName='+screenname+'&sidId='+sidid)
      //this.http.get(apiURL1)
      .toPromise()
        .then(
          res => { // Success
            //console.log(this.valuMarkets.find(res => res.sidType));
             this.valuMarkets = JSON.parse(res.json()["MARKETS"]);
            this.reasonCode = JSON.parse(res.json()["REASON CODE"]);
             for (var i = 0; i < this.valuMarkets.length; i++) {
              let valueGroup = this.valuMarkets[i];
              let multipledropdownOption = new multipledropdown();
              multipledropdownOption.item_id = valueGroup.name;
              multipledropdownOption.item_text = valueGroup.name;
              this.marketContactList.push(multipledropdownOption);
              //console.log("this.marketContactList----------" + JSON.stringify(this.marketContactList));
              this.marketContactList = JSON.parse(JSON.stringify(this.marketContactList));
            }
            for (var i = 0; i < this.reasonCode.length; i++) {
              let valueRessonCode = this.reasonCode[i];
              let multipledropdownOption = new multipledropdown();
              multipledropdownOption.item_id = valueRessonCode.name;
              multipledropdownOption.item_text = valueRessonCode.name;
              this.reasonCodeList.push(multipledropdownOption);
              //console.log("this.marketContactList----------" + JSON.stringify(this.marketContactList));
              this.reasonCodeList = JSON.parse(JSON.stringify(this.reasonCodeList));
            }
          },
          msg => { // Error
            reject(msg);
          }
        );
    });
    return promise;
  }

  coreApproval() {
    let promise = new Promise((resolve, reject) => {
      this.http.get(this.apiRoot+'/restservices/helloworld/v1/service/getApproverOptions?approverType=QUICKUPDATE')
        .toPromise()
        .then(
          res => { 
            let multipledropdownOption ;
            this.valueProductAppover = res.json().quickUpdate["product"];//read this way
            for (var i = 0; i < this.valueProductAppover.length; i++) {
              let valueGroup = this.valueProductAppover[i];
              multipledropdownOption = valueGroup.name+':'+valueGroup.firstName + ',' + valueGroup.lastName + ':' + valueGroup.userName;
            this.productApproverList.push(multipledropdownOption);
            this.productApproverList = JSON.parse(JSON.stringify(this.productApproverList));

             /* let multipledropdownOption = new multipledropdown();
              multipledropdownOption.item_id = valueGroup.name;
              multipledropdownOption.item_text = valueGroup.name+':'+valueGroup.firstName + ',' + valueGroup.lastName + ':' + valueGroup.userName;
              this.productApproverList.push(multipledropdownOption);
              this.productApproverList = JSON.parse(JSON.stringify(this.productApproverList));*/
            }

            // this.valueChannelAppover = (res.json()["channel"]);
             //this.valueAlternateAppover = (res.json()["alternate"]);
             //console.log("actual:"+this.productApproverList);

          },
          msg => { // Error
            reject(msg);
          }
        );
    });
    return promise;
  }

  public  getNarrativeDatabySIDId(sidId,activity) {
    
    //console.log("getNarrativeDataby::SIDId="+sidId+":::Task Name="+activity);
    var url = this.apiRoot+'/restservices/helloworld/v1/service/getNarrativeDetails?sidId='+sidId;
      this.httpClient.get(url).subscribe( data => {
        //console.log("data from DB====>==DB=="+JSON.stringify(data));
      let nrtveData=data['narrative'];

      console.log("getNarrativeDataby:NARRATIVE PAGE::requester:===="+nrtveData.requestorName);
      var reqattuid = nrtveData.requestorName.split(":")[1];
      var bdattuid =nrtveData.bdContactName.split(":")[1];
      this.valueRequiredCoreAppover=nrtveData.requiredCoreApproval;
      this.requesterselectItems = [{item_id:reqattuid,item_text:nrtveData.requestorName}];
      this.bdContactSelectItems=[{item_id:bdattuid,item_text:nrtveData.bdContactName}];
      //this.selectedmarketContactList=[{item_id:bdattuid,item_text:nrtveData.bdContactName}];
      //requestorName: [this.requesterselectItems, Validators.required],
      //this.narrativeForm.removeControl('requestorName');
      //this.narrativeForm.addControl('requestorName', new FormControl(this.requesterselectItems,Validators.required));
this.narrativeForm = this.formBuilder.group({
  requestedDate: ['2018-11-13', Validators.required],
  marketNarOverallReq:[nrtveData.marketNarOverallReq,Validators.required],
  friendlyName:[nrtveData.friendlyName],
  impactWifi:[nrtveData.impactWifi],
  telegenceImpacted:[nrtveData.telegenceImpacted],
  requiredCoreApproval:[nrtveData.requiredCoreApproval],
  titanEnabledImpacted:[nrtveData.titanEnabledImpacted],
  sidRestriction:[nrtveData.sidRestriction],
  itProposedDate:[nrtveData.itProposedDate],
  titanEnablerProposedImplementationDate:[nrtveData.titanEnablerProposedImplementationDate],
  marketNarComments:[nrtveData.comments],
  //bdContactName:new FormControl([this.bdContactSelectItems])
      });
    });
  }
}
      
