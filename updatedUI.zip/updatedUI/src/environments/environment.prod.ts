export const environment = {
  production: true,
  firstApiCall: 'https://jsonplaceholder.typicode.com/todos/1',
  secondApiCall: 'http://localhost:8080/users/test'
};
