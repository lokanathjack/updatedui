const assert = require('chai').assert;
const appRoot = require('app-root-path');
var passwordDecrypter = require(appRoot.path+'/helperfunctions/password-decrypter');
var tools = require(appRoot.path+'/helperfunctions/tools.js');

//const configuration = require(appRoot.path+'/config/override-configs.json');
//----------
const rimraf = require('rimraf');
const path = require('path');
const fs = require('fs');
var configuration;
const dirExist = fs.existsSync(path.resolve(process.cwd(),'config-map'));
const configDirExist = fs.existsSync(path.resolve(process.cwd(),'config'));

if (dirExist) {
    if (configDirExist) {
        rimraf(path.resolve(process.cwd(),'config'),function (err) {
            if (err) {
                console.log('config folder is not found, it may removed already');
            }else {
                console.log('config folder removed');
            }
        });
    }
    configuration = require(path.resolve(process.cwd(),'./config-map/override-configs.json'));
}else {
    (function (dir) {
        try {
            fs.statSync(dir);
            console.log('config-map dir is not exist, config dir exists');
            console.log('getting configurations from config folder...');
            configuration = require(path.resolve(process.cwd(),'./config/override-configs.json'));
        } catch (e) {
            console.log('could not get config from config folder');
        }
    })('config');
}
//----------------

describe('Testing PasswordDecrypter', function() {
    describe('when encriptedPassword is correct', function() {
        it('PasswordDecrypter should return actual password', function(){
            let actualPassword = "testAnsc"
            let encriptedPassword = "475e7e5e9ce175e6";
            assert.equal(passwordDecrypter(encriptedPassword, appRoot.path+'/test/UnitTest/mocha_tests/key.pem'), 'testAnsc');
        });
    });
    describe('when encriptedPassword is wrong', function() {
        before(function(){
            passwordDecrypter.keyLocation = './key.pem';
        });
        it('PasswordDecrypter should not return actual password', function(){
            let actualPassword = "testAnsc"
            let encriptedPassword = "475e7e5e9ce175e7";
            assert.notEqual(passwordDecrypter(encriptedPassword, appRoot.path+'/test/UnitTest/mocha_tests/key.pem'), 'testAnsc');
        });
    });
});

describe('Testing getPrefix function', function() {
        it('getPrefix should return tss standard prefix', function(){
            assert.equal(tools.getUrlPrefix(), `/rest/${configuration.appName}`);
        });
});


