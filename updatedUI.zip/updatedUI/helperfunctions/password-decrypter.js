const crypto = require('crypto');
const appRoot = require('app-root-path');
const fs = require('fs');
const logger= require('@com.att.ajsc/1t-logging').logger;
const algorithm = 'aes-256-ctr';

var decrypt = (encryptPassword, keyLocation) => {
    //this.keyLocation = appRoot.path+'/secrets/mechid_password_key.pem';
    this.key='';
    try {
        if (fs.existsSync(keyLocation)) {
            this.key =  fs.readFileSync(keyLocation);
            console.log("keyLocation:"+keyLocation)
            var decipher = crypto.createDecipher(algorithm,this.key)
            var dec = decipher.update(encryptPassword,'hex','utf8')
            dec += decipher.final('utf8');
            return dec;
        }
        else {
            logger.info("key file not found in location "+keyLocation+ "so assuming password is not encrypted");
            return encryptPassword;
        }
    }
    catch(e) {
        logger.error(e);
    }
}

module.exports = decrypt;