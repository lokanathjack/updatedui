const fs = require('fs');
const path = require('path');
const configDirExist = fs.existsSync(path.join(process.cwd(),'config'));

const checkForConfig = () => {
    if (configDirExist) {
        console.log(configDirExist);
        return true;
    }
    else {
        console.log(configDirExist);
        return false;
    }
}

module.exports = {checkForConfig};